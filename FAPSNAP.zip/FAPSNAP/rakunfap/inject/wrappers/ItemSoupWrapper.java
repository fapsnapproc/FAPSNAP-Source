package juul.inject.wrappers;

import java.awt.image.BufferedImage;

import juul.Juul;
import juul.inject.LUT.Version;
import juul.inject.Wrapper;

public class ItemSoupWrapper extends Wrapper {

	public ItemSoupWrapper() {
		super("net.minecraft.item.ItemSoup");
	}
	
}
