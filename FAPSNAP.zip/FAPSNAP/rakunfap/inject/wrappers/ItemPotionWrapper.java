package juul.inject.wrappers;

import java.awt.image.BufferedImage;

import juul.Juul;
import juul.inject.LUT.Version;
import juul.inject.Wrapper;

public class ItemPotionWrapper extends Wrapper {

	public ItemPotionWrapper() {
		super("net.minecraft.item.ItemPotion");
	}
	
}
