package juul.event;

public class EventUpdate extends Event<EventUpdate> {

}
