package juul.event;

public class EventTick extends Event<EventTick> {

}
