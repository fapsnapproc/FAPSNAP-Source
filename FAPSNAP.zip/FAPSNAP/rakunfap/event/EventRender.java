package juul.event;

public class EventRender extends Event<EventRender> {

}
